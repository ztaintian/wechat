/*
* @Author: 新思
* @Date:   2017-01-19 11:48:56
* @Last Modified by:   新思
* @Last Modified time: 2017-01-19 11:50:25
*/

'use strict';
import IndexView from  '../views/IndexView.vue'
export default [{
	path:'/',
	component:IndexView,
}]