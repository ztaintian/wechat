/*
* @Author: 新思
* @Date:   2017-01-19 11:32:31
* @Last Modified by:   新思
* @Last Modified time: 2017-01-19 11:34:48
*/

'use strict';
export const personProducts = 'personProducts'
export const setPrice= 'setPrice'