/*
* @Author: 新思
* @Date:   2017-01-19 11:33:42
* @Last Modified by:   新思
* @Last Modified time: 2017-01-19 11:34:34
*/

'use strict';
export const setPrice= 'setPrice'
export const personProducts = 'personProducts'